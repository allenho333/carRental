APP_HOST = 'localhost'
APP_PORT = 7864
# allow CORS
ALLOW_CORS = True
